package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.FindCity;
import service.JobService;

/**
 * Servlet implementation class ResponseServlet
 */
public class ResponseServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = resp.getWriter();
		int pincode=Integer.parseInt(req.getParameter("pin"));
		String city=new FindCity().getCity(pincode);
		String technology=req.getParameter("tech");
		out.print(pincode+ " "+technology+" "+city);
		out.print("</br></br>");
		JobService jobs= new JobService();
		List<String> list= jobs.getJobList(technology, city);
		for(String st:list) {
			out.println(st+",");		
		}
		
		out.print("<a href='SerachJobs.html'><h3>Login Again<h3></a>");
	}
	
}
