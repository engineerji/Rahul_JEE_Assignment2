package server;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ValidationServlet
 */
public class ValidationServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		String pincode=req.getParameter("pincode");
		String technology=req.getParameter("tech");
		if(pincode.length()==1) {
			out.print("<a href='ResponseServlet?pin="+pincode+"&tech="+technology+"'><h3>Find Jobs</h3></a>");
		}
		else {
			out.print("Invalid pincode");
			out.print("<a href='SerachJobs.html'><h3>Login Again<h3></a>");
		}
	}
	
	
}
