package service;

import java.util.HashMap;

public class FindCity {
	HashMap<Integer, String> list= new HashMap();
	
	public HashMap<Integer,String> getList() {
		list.put(1,"Delhi");
		list.put(2,"Mumbai");
		list.put(3,"Pune");
		list.put(4,"Banglore");
		list.put(5,"Hyderabad");
		return list;
	}
	public String getCity(int pin) {
		HashMap<Integer,String> nlist=getList();
		System.out.println(nlist.get(pin));
		return nlist.get(pin);
	}

}
